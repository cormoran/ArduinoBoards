#include<Arduino.h>
#include<SPI.h>
#include<mcp_can.h>
#include"can_communication.h"
static MCP_CAN CAN(CAN_CS);
CanCommunication CanCom;

/**
 *
 * CanCommunicatioin
 *
 */

/* private */

uint8_t CanCommunication::self_addr;
byte CanCommunication::can_buf[8];
uint8_t CanCommunication::can_buf_len;
void (*CanCommunication::receive_callback)(uint16_t, const byte*, uint8_t);
void (*CanCommunication::error_callback)(uint8_t, uint8_t);    



void CanCommunication::onInterrupt() {
    uint8_t int_flg = CAN.getInterruptFlg();
    if(int_flg & (MCP_RX0IF | MCP_RX1IF)) {
        if(receive_callback != NULL) {
            if(CAN.readMsgBuf(&can_buf_len, can_buf) == CAN_OK) {                
                receive_callback(CAN.getCanId(), can_buf, can_buf_len);
            }
        }
    }
    if(int_flg & (MCP_MERRF | MCP_ERRIF)) {
        if(error_callback != NULL) {
            error_callback(int_flg, CAN.getErrorFlg());
        }
        CAN.clearErrorFlg();
    }
}

void CanCommunication::debugPrintCanData(uint32_t id, const byte *buf, uint8_t len){
    Serial.println("- - CAN - - - - -");
    Serial.println("ID : ");
    Serial.print("TYPE ");
    Serial.print(getDataTypeFromStdId(id), BIN);
    Serial.print(" Src ");
    Serial.print(getSrcFromStdId(id), HEX);
    Serial.print(" Dest ");
    Serial.println(getDestFromStdId(id), HEX);
    Serial.println("Data : ");
    for(uint8_t i = 0; i<len; i++){
        Serial.print(buf[i], HEX);
        Serial.print(" ");
    }
    Serial.println("");
}




/* public */

uint8_t CanCommunication::begin(uint8_t self_addr, uint8_t speedset) {
    // CAN初期化
    while( CAN.begin(speedset) != CAN_OK ){
#ifdef DEBUG
        Serial.println("CAN init failing");
#endif
        delay(10);
    }
    return setSelfAddr(self_addr);
}

/**
 * @fn     
 * 自分のCAN通信アドレスを設定
 * 同時に受信するデータを、自分宛のものに限定する
 * @param (addr) アドレス下位4bitのみ有効
 * @return CAN_OK or CAN_FAIL
 */
uint8_t CanCommunication::setSelfAddr(uint8_t addr) {
    this->self_addr = addr & 0x0F;
    return setReceiveFilter(true);
}

/**
 * @fn     
 * 自分のアドレスを取得
 */
uint8_t CanCommunication::getSelfAddr() {
    return self_addr;
}

/**
 * @fn
 * 受信するデータをフィルタするかどうか設定する
 * @param (flg) true : 自分のアドレス宛のデータ & broadcastのみ受信
 *              false: すべてのデータを受信
 * @return CAN_OK or CAN_FAIL
 */
uint8_t CanCommunication::setReceiveFilter(bool flg) {
    uint8_t ret = 0;
    if(flg) {
        ret |= CAN.init_Mask(0, 0, 0x0F); // 送信先だけ見る
        ret |= CAN.init_Mask(1, 0, 0x0F);
    } else {
        ret |= CAN.init_Mask(0, 0, 0x00);
        ret |= CAN.init_Mask(1, 0, 0x00);
    }
    ret |= CAN.init_Filt(0, 0, 0x0); // broadcast message
    ret |= CAN.init_Filt(1, 0, this->self_addr); // 自分宛
    return ret == 0 ? CAN_OK : CAN_FAIL;
}

/**
 * @fn
 * @param (command_type) 送るデータのタイプ CAN_DATA_TYPE_xxxx
 * @param (dest) 送り先アドレス（下位4bit）
 * @param (data) データ
 * @param (len) データ長
 * @return CAN_OK or CAN_FAIL
 */
uint8_t CanCommunication::sendData(uint8_t data_type, uint8_t dest, const byte *data, uint8_t len) {
    return CAN.sendMsgBuf(generateStdId(data_type, self_addr, dest),0, len, (byte*)data);
}

/**
 * @fn
 * データを受信していれば取得する関数
 * @param (std_id) データがあれば、そのstanderd_idが格納される
 * @param (data) データがあれば、格納される 8byte以上の配列である必要あり
 * @param (len) データがあれば、そのサイズが格納される格納
 * @return CAN_OK or CAN_FAIL (受信データなし)
 */
uint8_t CanCommunication::receiveData(uint16_t *std_id, byte *data, uint8_t *len) {
    if( CAN.readMsgBuf(len, data) == CAN_OK ) {
        *std_id = (uint16_t)CAN.getCanId();
        return CAN_OK;
    } else return CAN_FAIL;
}


/**
 * @fn
 * データ受信時に割り込みを設定する関数
 * @param (callback) データ受信時に呼び出される関数 引数(std_id, data, len)
 */
void CanCommunication::onReceive(void (*callback)(uint16_t, const byte*, uint8_t)) {
    this->receive_callback = callback;
    attachInterrupt(digitalPinToInterrupt(CAN_INT), onInterrupt, FALLING);
}

/**
 * @fn
 * 通信等のエラー発生時に割り込みを設定する関数
 * @param (callback) エラー時に呼び出される関数 引数(interrupt_flg, error_flg)
 * @detail callbackの引数のflgはMCP2515のデータシート参照
 */
void CanCommunication::onError(void (*callback)(uint8_t, uint8_t)) {
    this-> error_callback = callback;
    attachInterrupt(digitalPinToInterrupt(CAN_INT), onInterrupt, FALLING);
    CAN.setErrorInterrupt(true);
}


uint8_t CanCommunication::sendHeartBeat() {
    static uint32_t cnt = 0;
    uint8_t ret =  CAN.sendMsgBuf(
        generateStdId(CAN_DATA_TYPE_HEARBEAT, self_addr, CAN_ADDR_BROADCAST),
        0, 4, (byte*)&cnt);
    ++cnt;
    return ret;
}


uint16_t CanCommunication::generateStdId(uint8_t data_type, uint8_t src, uint8_t dest) {
    return (uint16_t)data_type << 8 | (uint16_t)(src & 0x0F) << 4 | (uint16_t)(dest & 0x0F);
}
uint8_t CanCommunication::getDataTypeFromStdId(uint16_t std_id) {
    return std_id >> 8;
}
uint8_t CanCommunication::getSrcFromStdId(uint16_t std_id) {
    return (std_id & 0xF0) >> 4;    
}
uint8_t CanCommunication::getDestFromStdId(uint16_t std_id) {
    return std_id & 0x0F;
}
