#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include "pins_arduino_standard.h"
#undef NUM_ANALOG_INPUTS
#define NUM_ANALOG_INPUTS           8

#include "hardware_profile.h"


#endif
